const crcLib = require('crc')

class Frame {
    constructor(crc, command, data){
        this.crc = crc
        this.command = command
        this.data = data
        this.valid = false
    }

    /**
     * Funkcja tworzy nową ramkę na podstawie przekazanych argumentów
     * 
     * @param {string} command ID Komendy
     * @param {string} data  Wartość do przesłania
     * @returns {Frame} Zwraca nową ramkę
     */

    static from = (command, data) => {
        let newFrame = new Frame(null, command, data)
        newFrame.crc = newFrame.calculateCRC()
        return newFrame
    }

    /**
     * Parsuje surowe dane
     * 
     * @param {string} raw 
     * @returns {Frame}
     */

    static parse = (raw) => {
        const crc = raw.slice(4, 12)
        const command = raw.slice(12, 13)
        const data = raw.slice(13)

        let newFrame = new Frame(crc, command, data)
        newFrame.validate()
        return newFrame
    }

    /**
     * Oblicza i zwraca CRC32 komendy i danych
     * 
     * @returns {string} CRC32
     */

    calculateCRC = () => {
        let crc = crcLib.crc32(this.command + this.data).toString(16).toUpperCase()
        return "0".repeat(8 - crc.length) + crc
    }

    /**
     * Walidacja sumy kontrolnej
     */

    validate = () => {
        this.valid = this.calculateCRC() == this.crc
    }

    /**
     * Zwraca ramkę w postaci gotowej do wysłania
     * 
     * @returns {string}
     */

    toString = () => {
        return "MSDK" + this.crc + this.command + this.data
    }
}

module.exports = Frame