const { app, BrowserWindow, ipcMain } = require("electron"),
      {setUART, listPorts, sendResolutionRequest} = require("./serial.js"),
      Router = require("./router.js"),
      Sensors = require("./sensors.js"),
      Camera = require("./camera.js"),
      showPopup = require('./popupControl.js')

const settings = {"resolution": 6}

// Główny kod wykonywany w momencie zgłoszenia gotowości
function Main() {
    // Nowe okno
    win = new BrowserWindow({width: 1280, height: 720, icon: "icon.ico", webPreferences: { nodeIntegration: true, contextIsolation: false }, frame: false})
    win.loadURL("file://"+__dirname+"/html/index.html")

    const router = new Router()
    const sensors = new Sensors(win)

    let camera = null
    let resolutionToApply = null
    let port = null

    // Handling komendy
    router.on("O", sensors.updateOxygen)
    router.on("J", sensors.updateAccelerometer)
    router.on("P", sensors.updatePressTempHeight)
    router.on("R", (data) => {
        settings["resolution"] = data
    })
    router.on("S", () => {
        showPopup("Rozdzielczość kamery została zmieniona", "#3beb75", win)
        if (resolutionToApply) {
            settings["resolution"] = parseInt(resolutionToApply)
            resolutionToApply = null
        }
    })

    // Handling eventów od klienta
    ipcMain.on("getResolution", (event, arg) => {
        event.sender.send("getResolution", settings["resolution"])
    })
    ipcMain.on("getChartsData", sensors.sendAllData)
    ipcMain.on("saveChart", sensors.saveCSV)
    ipcMain.on("getCOMports", (event, arg) => {
        listPorts().then(ports => {
            event.sender.send("getCOMports", ports)
        })
    })

    // Funkcja wyświetlająca błąd po stronie klienta
    function notConnectedError(){
        showPopup('Nie połączono z satelitą!', '#f35757', win)
    }

    ipcMain.on("requestImage", notConnectedError)
    ipcMain.on("setCameraSettings", notConnectedError)

    ipcMain.on("setCOMport", (event, arg) => {
        if (port?.path == arg) return
        port?.close()
        port = setUART(arg, frame => router.execute(frame))

        camera = new Camera(win, port)
        router.on("I", camera.receiveImage)
        ipcMain.on("requestImage", camera.requestImage)
        ipcMain.on("requestLastImage", camera.sendImage)
        ipcMain.on("setCameraSettings", (event, arg) => {
            resolutionToApply = arg
            camera.setCameraSettings(arg)
        })
        sendResolutionRequest(port)
        sendResolutionRequest(port)
        sendResolutionRequest(port)
    })
    ipcMain.on("getCurrentCOMport", (event, arg) => {
        event.sender.send("getCurrentCOMport", port?.path)
    })
}

ipcMain.on('windowEvent', (event, arg) => {
    switch(arg){
        case 'exit':
            app.exit(0);
            break;
        case 'hide':
            win.minimize();
            break;
        case 'mtog':
            if (win.isMaximized()) {
                win.unmaximize()
            } else {
                win.maximize()
            }
            break;
        default:
            break;
    }
})

app.on("ready", Main)