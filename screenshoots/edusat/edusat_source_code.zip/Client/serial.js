const { SerialPort } = require('serialport')
const { ReadlineParser } = require('@serialport/parser-readline')
const Frame = require('./frame.js')
// let port = new SerialPort({path: 'COM4', baudRate: 9600})

/**
 * Parsuje dane otrzymane przez radio
 * 
 * @param {string} data Dane otrzymane przez radio
 * @returns {undefined}
 */

function parseData(raw){
    if(raw.lenght < 12) throw new Error("Wrong response")

    while(raw.length > 0 && raw.slice(0, 4) != "MSDK")
        raw = raw.slice(1)

    return Frame.parse(raw)
}

/**
 * Inicjalizacja UART
 * 
 * @param {function} callback(frame) Funkcja wykonywana po odebraniu ramki
 * @param {Frame} frame: odebrana i sparsowana ramka
 * @returns {SerialPort} Port UART
 */

function setUART(portName, callback){
    try {
        const port = new SerialPort({path: portName, baudRate: 9600})
        const parser = port.pipe(new ReadlineParser({delimiter: '\r\n'}))
        parser.on('data', raw => {
            callback(parseData(raw))
        })
        return port
    } catch (ex) {
        console.log(ex)
        return null
    }
}

/**
 * Zwraca promise z listą dostępnych portów
 * 
 * @returns {Promise} Promise z listą dostępnych portów
 */

async function listPorts(){
    return SerialPort.list()
}

/**
 * Wysyła request o ustawioną rozdzielczość kamery do satelity
 * 
 * @param {SerialPort} port Port na którym nadawane są dane do satelity
 */

function sendResolutionRequest(port){
    const resolutionRequestFrame = Frame.from("R", "")
    port.write(resolutionRequestFrame.toString())
}

/**
 * Wysyła request o zrobienie zdjęcia do satelity
 * 
 * @param {SerialPort} port Port na którym nadawane są dane do satelity
 */

function sendImageRequest(port){
    const imageRequestFrame = Frame.from("I", "")
    port.write(imageRequestFrame.toString())
}

/**
 * Wysyła request o zmianę rozdzielczości kamery do satelity
 * 
 * @param {SerialPort} port Port na którym nadawane są dane do satelity
 * @param {string} resolution Rozdzielczość kamery
 */

function sendImageSettings(port, data){
    const imageSettingsFrame = Frame.from("S", data)
    port.write(imageSettingsFrame.toString())
}

module.exports = {setUART, listPorts, sendImageRequest, sendImageSettings, sendResolutionRequest}