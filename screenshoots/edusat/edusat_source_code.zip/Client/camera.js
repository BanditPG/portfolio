const {sendImageRequest, sendImageSettings} = require("./serial.js")
const fs = require("fs")
const showPopup = require("./popupControl.js")
const {dialog} = require('electron')

/*
    Klasa Camera zarządza zdjęciami i komunikacją z kamerą.
*/

class Camera {
    constructor(window, port){
        this.windowSend = window
        this.port = port
        this.image = Buffer.from("")
        this.ended = true
    }

    /**
     * Wysyła do satelity request o zdjęcie
     */
    
    requestImage = () => {
        if(this.ended){
            this.image = Buffer.from("")
            sendImageRequest(this.port)
        } else {
            showPopup('Zdjęcie jest już w trakcie wysyłania!', '#f35757', this.windowSend)
        }
    }

    /**
     * Odbiera dane z kamery i wysyła je do klienta lub zapisuje zdjęcie
     * 
     * @param {string} data  Dane z kamery
     */

    receiveImage = (data) => {
        if(data == "START_IMAGE"){
            this.ended = false
            showPopup('Odbieranie zdjęcia', '#3beb75', this.windowSend)
        } else if(data == "END_IMAGE"){
            this.saveImage()
            this.ended = true
        } else {
            const processData = Buffer.from(data, "hex")
            this.image = Buffer.concat([this.image, processData])
            this.sendImage()
        }
    }

    /**
     * Zapisuje zdjęcie
     */

    saveImage = async () => {
        const d = new Date();
        const src = `${d.getFullYear()}_${d.getMonth()}_${d.getDay()}_${d.getHours()}-${d.getMinutes()}-${d.getSeconds()}-${d.getMilliseconds()}.jpg`;
        
        const fileName = await dialog.showSaveDialog(this.windowSend, {
            filters: [
                {name: 'Plik JPEG', extensions: ['jpg', 'jpeg']}
            ],
            defaultPath: src
        })

        try {
            fs.writeFile(fileName.filePath, this.image, (err) => {
                if(err) showPopup('Błąd podczas zapisywania zdjęcia', '#f35757', this.windowSend) 
                else showPopup('Zdjęcie zostało zapisane jako ' + fileName.filePath, '#3beb75', this.windowSend)
            })
        } catch (ex) {
            showPopup('Wystąpił błąd podczas zapisywania zdjęcia', '#f35757', this.windowSend)
        }
    }
    
    /**
     * Wysyła zdjęcie do klienta
     */

    sendImage = () => {
        this.windowSend.webContents.send('getImageData', this.image.toString('base64'))
    }

    /**
     * Wysyła żądanie zmiany ustawień do kamery
     * 
     * @param {string} data Nowe ustawienia kamery
     */

    setCameraSettings = (data) => {
        if(this.ended){
            sendImageSettings(this.port, data)
            showPopup('Wysłano żądanie zmiany ustawień', '#3beb75', this.windowSend)
        } else {
            showPopup('Nie można zmienić rozdzielczości podczas odbierania zdjęcia', '#f35757', this.windowSend)
        }
    }
}

module.exports = Camera