/*
    Klasa Router ma za zadanie obsługiwać eventy od satelity.
*/

class Router {
    constructor(){
        this.routes = {}
    }

    /**
     * Ustawia callback dla danego eventu
     * 
     * @param {string} command Event - id komendy 
     * @param {function} callback Funkcja, która zostanie wykonana gdy nastąpi dany event
     */

    on = (command, callback) => {
        this.routes[command] = callback
    }

    /**
     * Metoda wykonująca przypisany callback dla danego eventu w ramce
     * 
     * @param {Frame} frame 
     */

    execute = (frame) => {
        if(this.routes[frame.command] && frame.valid){
            this.routes[frame.command](frame.data)
        }
    }
}

module.exports = Router