(()=>{
    const { ipcRenderer } = require("electron")
    const scene = new THREE.Scene();
    const canvas1 = document.getElementById('modelRotation');
    const camera = new THREE.PerspectiveCamera( 75, canvas1.width/canvas1.height/1.5, 0.1, 1000 );
    const gridSize = 10;
    const gridDivisions = 20;
    let offsets = sessionStorage.getItem("offsets")?.split(",").map(x => parseFloat(x)) || [0, 0, 0]
    scene.background = new THREE.Color(0x555555);

    /**
     * Skaluje canvas z wizualizacją aby zapewnić responsywność
     */

    function scaleCanvas(){
        canvas1.style.width = 1.5*window.innerWidth/4 + "px"
        canvas1.style.height = window.innerHeight/2 + "px"
        renderer.render(scene, camera)
    }

    // Inicjalizacja renderera

    const renderer = new THREE.WebGLRenderer({canvas: canvas1});
    renderer.setSize( window.innerWidth, window.innerHeight );

    // Ustawienia sceny

        // Pozycja kamery

        camera.rotation.x = -Math.PI/7
        camera.position.y = 2.5;
        camera.position.z = 4;

        // Siatka pomocnicza

        const gridHelper = new THREE.GridHelper( gridSize, gridDivisions, 0xff6384, 0x6384ff );
        scene.add( gridHelper );

        // Pierwsze światło

        const light1 = new THREE.PointLight( 0xffffff, 1, 20 );
        light1.position.set( 0, 5, -4 );
        scene.add( light1 )

        // Drugie światło

        const light2 = new THREE.PointLight( 0xffffff, 1, 20 );
        light2.position.set( 0, 5, 4 );
        scene.add( light2 )

    // Ładowanie modelu satelity z pliku .glb, wizualizacja danych z czujników i interpolacja w celu zapewnienia płynności animacji

    const loader = new THREE.GLTFLoader();

    loader.load('./three/model.glb', function (gltf) {
        let kostka = gltf.scene.children[0]

        kostka.scale.set(0.02, 0.02, 0.02)
        kostka.position.set(0, 0, 0);

        scene.add(kostka)

        // Dane z czujników

        let nowArgs = [0, 0, 0]
        ipcRenderer.on('updateAngles', (event, arg) => {
            nowArgs = [...arg]
        })

        // Kalibracja modelu satelitu (O - ustawienie rotacji względnej, P - resetowanie rotacji względnej)

        window.onkeydown = (e) => {
            if(e.keyCode == 79){ // O
                offsets = [kostka.rotation.x, kostka.rotation.y, kostka.rotation.z]
                sessionStorage.setItem("offsets", offsets)
            } else if(e.keyCode == 80){ // P
                offsets = [0, 0, 0]
                sessionStorage.setItem("offsets", offsets)
            }
        }

        // Animacja ruchu modelu satelity (interpolacja między kolejnymi danymi z czujników)

        function coninuousInterpolation(){
            let newRotation = new THREE.Quaternion().setFromEuler(
                new THREE.Euler(-nowArgs[0] / 6.2 - offsets[0], 
                0, 
                -nowArgs[1] / 6 - 0.22 - offsets[2]
            ))
            
            kostka.quaternion.slerp(newRotation, 0.08)

            renderer.render(scene, camera)
            requestAnimationFrame(coninuousInterpolation)
        }

        coninuousInterpolation()
    }, undefined, function (error) {})

    scaleCanvas()
    window.onresize = scaleCanvas
})()