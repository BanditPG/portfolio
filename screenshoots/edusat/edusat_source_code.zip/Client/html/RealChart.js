/*
    Klasa RealChart tworzy i obsługuje wykres danych z czujnika.
*/

class RealChart {
    constructor(canvas){
        this.canvas = canvas
        this.ctx = this.canvas.getContext('2d')
        this.chart = null
    }

    /**
     * Inicjalizacja wykresu
     * 
     * @param {string} title Tytuł wykresu
     * @param {string} color Kolor wykresu
     */

    initChart = (title, color) => {
        this.chart = new Chart(this.ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: title,
                    backgroundColor: color,
                    borderColor: color,
                    data: [],
                    borderWidth: 1
                }]
            },
            options: {
                animations: false,
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#fff'
                        }
                    }
                }
            }
        });
    }

    /**
     * Aktualizuje dane wykresu
     * 
     * @param {Array} data 
     */

    updateData = (data) => {
        this.chart.data.datasets[0].data = data.map(x => x[0])
        moment.locale('pl')
        this.chart.data.labels = data.map(x => moment(x[1]).format("LTS"))
        this.chart.update();
    }
}

const charts = {
    "pressure": null,
    "temperature": null,
    "height": null,
    "oxygen": null,
    "ozone": null,
    "uv": null,
}

const plTranslator = {
    "pressure": "Ciśnienie",
    "temperature": "Temperatura",
    "height": "Wysokość",
    "oxygen": "Tlen",
    "ozone": "Ozon",
    "uv": "UV",
}

/**
 * Inicjalizuje wszystkie wykresy
 */

function initCharts(){
    const charts_titles = Object.keys(charts)
    for(let i = 0; i < charts_titles.length; i++){
        const chartName = charts_titles[i]
        const chart = new RealChart(document.getElementById(chartName))
        const color = i % 2 ? 'rgb(255, 99, 132)' : 'rgb(99, 132, 255)'

        chart.initChart(plTranslator[chartName], color)
        charts[chartName] = chart
    }
}