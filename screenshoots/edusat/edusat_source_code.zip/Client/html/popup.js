const { ipcRenderer } = require("electron");

let popupTimeout1 = 0, popupTimeout2 = 0;
const popupElement = document.getElementById('popup');

/*
    Kod wyświetlający wiadomość od serwera po stronie klienta
*/

ipcRenderer.on('changeSettings', (evt, arg) => {
    clearTimeout(popupTimeout1)
    clearTimeout(popupTimeout2)
    
    popupElement.style.zIndex = "99999";
    popupElement.style.opacity = "1";
    document.getElementById('zmiana').innerHTML = arg.message
    popupElement.style.background = arg.background
    popupTimeout1 = setTimeout(() => {
        popupElement.style.opacity = "0";
        popupTimeout2 = setTimeout(() => {
            popupElement.style.zIndex = "-99999";
        }, 500)
    }, 5000)
})