/**
 * Wyświetla wiadomość po stronie klienta
 * 
 * @param {string} message Wiadomość do wyświetlenia
 * @param {string} background Kolor tła
 * @param {BrowserWindow} windowSend Okno do którego wysyłane są dane
 */

function showPopup(message, background, windowSend){
    windowSend.webContents.send('changeSettings', {
        background,
        message
    })
}

module.exports = showPopup