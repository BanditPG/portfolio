const {dialog} = require('electron')
const fs = require('fs')
const showPopup = require("./popupControl.js")

/*
    Klasa Sensors zarządza danymi z czujników.
*/

class Sensors {
    constructor(window){
        this.windowSend = window
        this.charts = {
            "temperature": [], // Temperatura
            "pressure": [], // Ciśnienie
            "height": [], // Wysokość
            "oxygen": [], // Tlen
            "ozone": [], // Ozon
            "uv": [] // UV
        }
        this.accelerometer = [0, 0, 0]
    }
    
    /**
     * Dodaje dane do odpowiedniego wykresu i wysyła je do klienta
     * 
     * @param {string} title Nazwa wykresu
     * @param {number} data  Dane do wykresu
     */

    applyData = (title, data) => {
        const timestamp = new Date().getTime()
        this.charts[title].push([data, timestamp])
        this.sendData(title)
    }

    /**
     * Wysyła dane konkretnego wykresu do klienta
     * 
     * @param {string} title Nazwa wykresu
     */

    sendData = (title) => {
        this.windowSend.webContents.send('updateChart', {
            title,
            data: this.charts[title]
        })
    }

    /**
     * Parsuje dane z czujnika, a następnie wywołuje metodę applyData
     * 
     * @param {string} data Dane z czujnika tlenu
     */

    updateOxygen = (data) => {
        const oxygenData = parseFloat(data)
        this.applyData('oxygen', oxygenData)
    }

    /**
     * Parsuje dane z czujnika, a następnie wywołuje metodę applyData
     * 
     * @param {string} data Dane z czujnika ciśnienia, temperatury i wysokości
     */

    updatePressTempHeight = (data) => {
        const dataSplit = data.split(";").map(x => parseFloat(x))
        
        this.applyData('pressure', dataSplit[0])
        this.applyData('height', dataSplit[1])
        this.applyData('temperature', dataSplit[2])
    }

    /**
     * Parsuje dane z czujnika, a następnie wysyła je do klienta
     * 
     * @param {string} data Dane z czujnika akcelerometru
     */

    updateAccelerometer = (data) => {
        const dataSplit = data.split(";").map(x => parseFloat(x))
        this.windowSend.webContents.send('updateAngles', dataSplit)
    }

    /**
     * Wysyła dane wszystkich wykresów do klienta
     */

    sendAllData = () => {
        Object.keys(this.charts).forEach(title => this.sendData(title))
    }

    /**
     * Zapisuje dane z wykresów do pliku .csv
     */

    saveCSV = async () => {
        const chartTitles = Object.keys(this.charts)
        let content = ''

        // Wypisuje tytuły wykresów
        for(let i = 0; i < chartTitles.length; i++)
            content += chartTitles[i] + ", ,"
        content += '\n'

        // Wypisuje dane z wykresów
        const max = Math.max(...chartTitles.map(x => this.charts[x].length))
        for(let j = 0; j < max; j++){
            for(let i = 0; i < chartTitles.length; i++){
                const thisChart = this.charts[chartTitles[i]]
                if(thisChart[j]){
                    const csvDate = new Date(thisChart[j][1])
                    content += (`${csvDate.getDay()}.${csvDate.getMonth()+1}.${csvDate.getFullYear()} ${csvDate.getHours()}:${csvDate.getMinutes()}:${csvDate.getSeconds()}` || "") + "," + (thisChart[j][0] || "") + ","
                } else {
                    content += ', ,'
                }
            }
            content += "\n"
        }
    
        // Tworzy dialog pytający o ścieżkę w której ma być zapisany plik .csv
        const fileName = await dialog.showSaveDialog(this.windowSend, {
            filters: [
                {name: 'Plik CSV', extensions: ['csv']}
            ]
        })
    
        // Zapisuje plik .csv
        if(fileName.filePath){
            await fs.writeFile(fileName.filePath, content, 'utf-8', (err) => {
                if(err) showPopup("Wystąpił błąd podczas zapisywania pliku", "#f35757", this.windowSend)
                else showPopup("Zapisano plik jako " + fileName.filePath, "#3beb75", this.windowSend)
             })
        }
    }
}

module.exports = Sensors