#include <Wire.h>
#include "soc/rtc_cntl_reg.h"  //disable brownout problems
#include "soc/soc.h" //disable brownout problems
#include "fb_gfx.h"


#include "frame.h"
#include "camera.h"
#include "sensors.h"
#include "parser.h"


#define I2C_SDA 15 //lewy
#define I2C_SCL 14 //prawy

#define ACC_DELAY 300 //Opóźnienie w wysyłaniu danych z akcelerometru
#define OTHER_DELAY 2000 //Opóźnienie w wysyłaniu danych z innych czujników

int currentTime;
int acc_interval = 0;
int pressure_delay = 1000;
int oxygen_delay = 1500;



void setup() {
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0);
  
  //otwarcie portu I2C
  Wire.begin(I2C_SDA, I2C_SCL);
  
  //otwarcie portu szeregowego
  Serial.begin(9600);

  //inicjalizacja kamery
  if(!init_camera()){
    while(true) {}
  }

  //inicjalizacja IMU
  initIMU();

  //inicjalizacja czujnika tlenu
  initOxygen();

  //inicjalizacja barmoetru
  initPressureSensor();
  Serial.println("READY");
}

//Odbieranie danych wysyłanych przez klienta
void msdk() {
  Frame frame = Frame();
  if(frame.readHeader()) {
    parser(&frame);
  }
}

void loop() {
  currentTime = millis();
  msdk();

  //Wysyłanie danych z IMU
  if(currentTime > acc_interval) {
    String data = get_IMU_data();
    Frame frame = Frame(&data, 'J');
    frame.send();

    acc_interval = millis() + ACC_DELAY;
  }

  //Wysyłanie danych z barometru
  if(currentTime > pressure_delay) {
    String data = get_pressure_data();
    Frame frame = Frame(&data, 'P');
    frame.send();

    pressure_delay = millis() + OTHER_DELAY;
  }

  //Wysyłanie danych z czujnika tlenu
  if(currentTime > oxygen_delay) {
    String data = get_oxygen_data();
    Frame frame = Frame(&data, 'O');
    frame.send();
    
    oxygen_delay = millis() + OTHER_DELAY;
  }
}