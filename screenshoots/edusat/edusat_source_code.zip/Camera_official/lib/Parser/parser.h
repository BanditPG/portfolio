
/**
 * Funkcja wykonująca odpowiednie funkcje na podstawie podanej ramki
 * Ramka przechowuje zmienną command, która determinuje odpowiednią funkcję
 */
void parser(Frame* frame);