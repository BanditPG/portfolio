#include "frame.h"
#include "camera.h"

void parser(Frame* frame) {
  switch (frame->command) 
  {
    case 'I':
      if(frame->valid()) {
        sendImageUart();
      }
      break;

    case 'S':
      if(frame->readData(2) && frame->valid()) {
        String numberStr = String(frame->data[0]);
        numberStr += frame->data[1];

        int resolution = numberStr.toInt();
        changeResolution(resolution);
        
        frame -> clean();
        Frame("OK", 2, 'S').send();
      }
      break;

    case 'R':
      if(frame->valid()) {
        String data = String(getResolution());
        Frame(&data, 'R').send();
      }

    default:
      break;
  }
}