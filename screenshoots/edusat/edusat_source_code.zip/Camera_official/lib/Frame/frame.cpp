#include "frame.h"
#include "CRC32.h"

Frame::Frame() {}

Frame::Frame(String* d, char cmd) {
  data = (char*) d->c_str();
  dataLength = d->length();
  command = cmd;

  crc = calculateCRC();
}

Frame::Frame(char const* d, int dl, char cmd) {
  data = (char*) d;
  dataLength = dl;
  command = cmd;

  crc = calculateCRC();
}

void Frame::clean() {
  delete[] data;
}

void Frame::send() {
  int frameLength = 15 + dataLength;
  char* buffer = new char[frameLength];
  
  buffer[0] = 'M';
  buffer[1] = 'S';
  buffer[2] = 'D';
  buffer[3] = 'K';

  for(int i=0; i<8; i++) {
    buffer[i+4] = hex[(crc & (0xf0000000 >> i*4)) >> (7-i)*4];
  }  

  buffer[12] = command;

  memcpy(&buffer[13], data, dataLength);

  buffer[13+dataLength]='\r';
  buffer[14+dataLength]='\n';

  while (Serial.availableForWrite() <= frameLength) {
    delay(10);
  }

  Serial.write(buffer, frameLength);
  delete[] buffer;
} 

bool Frame::valid() {
  uint32_t newCrc = calculateCRC();
  return newCrc == crc;
}

bool Frame::readData(int length) {
  data = new char[length];
  dataLength = length;
  return readFromUART(data, length);
}

bool Frame::readHeader() {
  return MSDK() && 
    readCrc() && 
    readCommand();
}

bool Frame::MSDK() {
  int uartIndex = 0;

  while (true) {
    if (uartIndex > 3) {
      return true;
    }

    if (Serial.available() >= 4-uartIndex) {
      char recv = Serial.read();
  
      if (msdk[uartIndex] != recv) {
        return false;
      }
      uartIndex += 1;
    } else {
      return false;
    }
  }
}

uint32_t Frame::calculateCRC() {
  CRC32 ownCrc;
  ownCrc.update(command);

  for(int i=0; i<dataLength; i++) {
    ownCrc.update(data[i]);
  }

  return ownCrc.finalize();
}

bool Frame::readCrc() {
  short int byteShift;
  char crcBuff[8];
  crc = 0;

  if (!readFromUART(crcBuff, 8)) {
    return false;
  }


  for(int i=0; i<8; i++) {
    byteShift = (7-i) * 4;

    if (crcBuff[i] < 58) {
      crc += (crcBuff[i] - 48) << byteShift;
    } else {
      crc += (crcBuff[i] - 55) << byteShift;
    }
  }

  return true;
}

bool Frame::readCommand() {
  return readFromUART(&command, 1);
}

bool Frame::readFromUART(char* buffer, int len) {
  for(int i=0; i<5; i++) {
    if(Serial.available() >= len) {
      Serial.readBytes(buffer, len);
      return true;
    }
    delay(10);
  }
  return false;
}