#include "CRC32.h"

//Klasa odpowiadająca za działanie protokołu
//Przetwarza dane wychodzące jak i przychodzące
class Frame {
  public:
    uint32_t crc;
    char command;
    char* data;
    int dataLength = 0;
  
  private:
    const char* msdk = "MSDK";
    const char* hex = "0123456789ABCDEF";

  public:
  
    Frame();
    Frame(String* data, char cmd);
    Frame(char const* d, int dl, char cmd);

    /**
     * Zwolnienie dynamicznie alokowanej pamięci przechowującej dane ramki
    */
    void clean();

    /**
     * Wysłanie obiektu ramki do klienta
    */
    void send();

    /**
     * Walidacja obiektu ramki
     * 
     * @return Wartość true/false w zależności od wyniku testu
     */
    bool valid();

    /**
     * Odczytanie nagłówka ramki z UART'u
     * 
     * @return Wartość true/false w zależności od tego czy
     *  porces odczytywania przebiegł pomyślnie
     */
    bool readHeader();

    /**
     * Odczytanie danych zawartych w ramce z UART'u
     * 
     * @param length Długość danych zawartych w ramce
     * @return Wartość true/false w zależności od tego czy
     *  porces odczytywania przebiegł pomyślnie
     */
    bool readData(int length);


    
  private:
    /**
     * Odczytanie preambuły ramki
     * 
     * @return Wartość true/false w zależności od tego czy
     *  porces odczytywania przebiegł pomyślnie
     */
    bool MSDK();

    /**
     * Obliczenie CRC32 na podstawie danych zawartych w obiekcie ramki
     * 
     * @return Wartość liczbowa CRC32
     */
    uint32_t calculateCRC();

    /**
     * Odczytanie CRC32 zawartego w przesyłanej ramce z UART'u
     * 
     * @return Wartość true/false w zależności od tego czy
     *  porces odczytywania przebiegł pomyślnie
     */
    bool readCrc();

    /**
     * Odczytanie komendy zawartej w przesyłanej ramce z UART'u
     * 
     * @return Wartość true/false w zależności od tego czy
     *  porces odczytywania przebiegł pomyślnie
     */
    bool readCommand();

    /**
     * Metoda odczytująca dane z UART'u
     * 
     * @param buffer tablica typu char do której dane mają zostać zapisane
     * @param len długość danych które mają zostać odczytane
     * @return Wartość true/false w zależności od tego czy
     *  porces odczytywania przebiegł pomyślnie
     */
    bool readFromUART(char* buffer, int len);
};
