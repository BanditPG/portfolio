#include "esp_camera.h"

/**
 * Inicjalizacja kamery
 * 
 * @return Wartość true/false w zależności od tego czy
 *  kamera została poprawnie zainicjalizowana
 */
bool init_camera();

/**
 * Pobieranie aktualnej rozdzielczości kamery
 * 
 * @return Rozdzielczość kamery
 */
int getResolution();

/**
 * Funkcja ustawiająca nową rozdzielczość kamery
 * 
 * @param resolution Rozdzielczość kamery
 */
void changeResolution(int resolution);

/**
 * Robienie zdjęcia i wysłanie go po UART
 */
void sendImageUart();