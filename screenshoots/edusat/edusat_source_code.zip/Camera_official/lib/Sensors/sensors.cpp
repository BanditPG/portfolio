#include "sensors.h"
#include "Adafruit_MPU6050.h"
#include "DFRobot_OxygenSensor.h"
#include "Adafruit_BMP3XX.h"


#define COLLECT_NUMBER    10
#define Oxygen_IICAddress ADDRESS_3

DFRobot_OxygenSensor Oxygen;
Adafruit_MPU6050 mpu;
Adafruit_BMP3XX bmp;

bool isIMU = true;
bool isOxygen = true;
bool isPressure = true;


void initIMU() {
  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050 chip");
    isIMU = false;
    return;
  }
  Serial.println("MPU6050 Found!");

  mpu.setAccelerometerRange(MPU6050_RANGE_2_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  delay(100);
}

void initOxygen() {
  if(!Oxygen.begin(Oxygen_IICAddress)) {
    Serial.println("Oxygen sensor failed: I2c device number error !");
    isOxygen = false;
    return;
  }
  Serial.println("Oxygen sensor found!");
}

void initPressureSensor() {
  if (!bmp.begin_I2C()) {
    Serial.println("Could not find a valid BMP3 sensor, check wiring!");
    isPressure = false;
    return;
  }

  bmp.setTemperatureOversampling(BMP3_OVERSAMPLING_8X);
  bmp.setPressureOversampling(BMP3_OVERSAMPLING_4X);
  bmp.setIIRFilterCoeff(BMP3_IIR_FILTER_COEFF_3);
  bmp.setOutputDataRate(BMP3_ODR_50_HZ);
}


String get_pressure_data() {
  if (!isPressure || !bmp.performReading()) {
    return String("");
  }

  String data = String(bmp.pressure / 100);
  data += ";";
  data += bmp.readAltitude(1013.25);
  data += ";";
  data += bmp.temperature;
  return data;
}

String get_oxygen_data() {
  if(!isOxygen) {
    return String("");
  }

  return String(Oxygen.getOxygenData(COLLECT_NUMBER));
}

String get_IMU_data() {
  if(!isIMU) {
    return String("");
  }

  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  String res = "";
  res += a.acceleration.x;
  res += ";";
  res += a.acceleration.y;
  res += ";";
  res += a.acceleration.z;
  res += ";";

  res += g.gyro.x;
  res += ";";
  res += g.gyro.y;
  res += ";";
  res += g.gyro.z;
  
  return res;

}