#include "Arduino.h"

/**
 * Inicjalizacja barometru
 */
void initPressureSensor();

/**
 * Odczytanie danych z barometru
 * 
 * @return Dane z barometru
 */
String get_pressure_data();

/**
 * Inicjalizacja czujnika tlenu
 */
void initOxygen();

/**
 * Odczytanie danych z czujnika tlenu
 * 
 * @return Dane z czujnika tlenu
 */
String get_oxygen_data();

/**
 * Inicjalizacja IMU
 */
void initIMU();

/**
 * Odczytanie danych z IMU
 * 
 * @return Dane z IMU
 */
String get_IMU_data();